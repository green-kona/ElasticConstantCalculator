public class Validator {
    private String inputValidator = "check";
}
