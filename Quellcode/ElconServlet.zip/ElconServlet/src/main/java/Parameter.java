public class Parameter {

    double c11 = 0;
    double c22 = 0;
    double c33 = 0;
    double c44 = 0;
    double c55 = 0;
    double c66 = 0;
    double c12 = 0;
    double c13 = 0;
    double c23 = 0;


    public void setElastischeKonstanten(
            double rho,
            double vpx,
            double vpy,
            double vpz,
            double vszy,
            double vsyz,
            double vszx,
            double vsxz,
            double vsxy,
            double vsyx,
            double vp45x,
            double vp45y,
            double vp45z
    ) {
        this.c11 = rho * Math.pow(vpx, 2);
        this.c22 = rho * Math.pow(vpy, 2);
        this.c33 = rho * Math.pow(vpz, 2);
        this.c44 = (rho * Math.pow(vszy, 2) + rho * Math.pow(vsyz, 2)) / 2;
        this.c55 = (rho * Math.pow(vszx, 2) + rho * Math.pow(vsxz, 2)) / 2;
        this.c66 = (rho * Math.pow(vsxy, 2) + rho * Math.pow(vsyx, 2)) / 2;
        this.c12 = Math.sqrt(4 * Math.pow(vp45x, 4) * Math.pow(rho, 2) - 2 * Math.pow(vp45x, 2) * c11 * rho - 2 * Math.pow(vp45x, 2) * c22 * rho - 4 * Math.pow(vp45x, 2) * c66 * rho + c11 * c22 + c11 * c66 + c22 * c66 + Math.pow(c66, 2)) - c66;
        this.c13 = Math.sqrt(4 * Math.pow(vp45y, 4) * Math.pow(rho, 2) - 2 * Math.pow(vp45y, 2) * c11 * rho - 2 * Math.pow(vp45y, 2) * c33 * rho - 4 * Math.pow(vp45y, 2) * c55 * rho + c11 * c33 + c11 * c55 + c33 * c55 + Math.pow(c55, 2)) - c55;
        this.c23 = Math.sqrt(4 * Math.pow(vp45z, 4) * Math.pow(rho, 2) - 2 * Math.pow(vp45z, 2) * c22 * rho - 2 * Math.pow(vp45z, 2) * c44 * rho - 4 * Math.pow(vp45z, 2) * c44 * rho + c22 * c33 + c22 * c44 + c33 * c44 + Math.pow(c44, 2)) - c44;
    }

    public double getC11() {
        return c11;
    }

    public double getC22() {
        return c22;
    }

    public double getC33() {
        return c33;
    }

    public double getC44() {
        return c44;
    }

    public double getC55() {
        return c55;
    }

    public double getC66() {
        return c66;
    }

    public double getC12() {
        return c12;
    }

    public double getC13() {
        return c13;
    }

    public double getC23() {
        return c23;
    }
}
