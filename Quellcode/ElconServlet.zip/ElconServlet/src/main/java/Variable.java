public class Variable {

    private double rho = 0;
    private double geschwindigkeit = 0;

    // Ein oder mehrere Zahlen, optionales Komma, optional ein oder mehrere Zahlen
    // Alternative: Zahlen und Kommata whitelisten [^0-9\^,]+
    private String regex = "^[0-9]+.?[0-9]*$";

    public double getGeschwindigkeit() {
        return geschwindigkeit;
    }

    public void setGeschwindigkeit(String geschwindigkeit) {
        if (geschwindigkeit.matches(regex)) {
            try {
                this.geschwindigkeit = Double.parseDouble(geschwindigkeit);
            } catch (NumberFormatException e) {
                System.out.println("Eine oder mehrere Eingaben sind keine Zahl");
            }
        } else {
            this.geschwindigkeit = 0;
        }
    }

    public double getRho() {
        return rho;
    }

    public void setRho(String rho) {
        if (rho.matches(regex)) {
            try {
                this.rho = Double.parseDouble(rho);
            } catch (NumberFormatException e) {
                System.out.println("Eine oder mehrere Eingaben sind keine Zahl");
            }
        } else {
            this.rho = 0;
        }
    }


}