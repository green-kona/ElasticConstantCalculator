import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Elcon extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        // Wert der POST-request mit Set-Methoden in Variable speichern
        Variable vrho = new Variable();
        vrho.setRho(req.getParameter("rho"));
        Variable vpx = new Variable();
        vpx.setGeschwindigkeit(req.getParameter("vpx"));
        Variable vpy = new Variable();
        vpy.setGeschwindigkeit(req.getParameter("vpy"));
        Variable vpz = new Variable();
        vpz.setGeschwindigkeit(req.getParameter("vpz"));
        Variable vsxy = new Variable();
        vsxy.setGeschwindigkeit(req.getParameter("vsxy"));
        Variable vsyx = new Variable();
        vsyx.setGeschwindigkeit(req.getParameter("vsyx"));
        Variable vszy = new Variable();
        vszy.setGeschwindigkeit(req.getParameter("vszy"));
        Variable vsyz = new Variable();
        vsyz.setGeschwindigkeit(req.getParameter("vsyz"));
        Variable vsxz = new Variable();
        vsxz.setGeschwindigkeit(req.getParameter("vsxz"));
        Variable vszx = new Variable();
        vszx.setGeschwindigkeit(req.getParameter("vszx"));
        Variable vp45x = new Variable();
        vp45x.setGeschwindigkeit(req.getParameter("vp45x"));
        Variable vp45y = new Variable();
        vp45y.setGeschwindigkeit(req.getParameter("vp45y"));
        Variable vp45z = new Variable();
        vp45z.setGeschwindigkeit(req.getParameter("vp45z"));


        Parameter orthothrop = new Parameter();

        orthothrop.setElastischeKonstanten(
                vrho.getRho(),
                vpx.getGeschwindigkeit(),
                vpy.getGeschwindigkeit(),
                vpz.getGeschwindigkeit(),
                vszy.getGeschwindigkeit(),
                vsyz.getGeschwindigkeit(),
                vszx.getGeschwindigkeit(),
                vsxz.getGeschwindigkeit(),
                vsxy.getGeschwindigkeit(),
                vsxy.getGeschwindigkeit(),
                vp45x.getGeschwindigkeit(),
                vp45y.getGeschwindigkeit(),
                vp45z.getGeschwindigkeit());

        /*
        ServletOutputStream out = resp.getOutputStream();
        out.println(vp45x.getGeschwindigkeit());
        out.println(vp45y.getGeschwindigkeit());
        out.println(vp45z.getGeschwindigkeit());
        out.println(orthothrop.getC12());
        out.println(orthothrop.getC13());
        out.println(orthothrop.getC23());
        //out.println(vrho.getRho());
        */

        //Request wird "frage" als Attribut mitgegeben, damit man mit EL darauf zugreifen kann

       // req.setAttribute("c11", vrho.getRho());
        req.setAttribute("c11", orthothrop.getC11());
        req.setAttribute("c22", orthothrop.getC22());
        req.setAttribute("c33", orthothrop.getC33());
        req.setAttribute("c44", orthothrop.getC44());
        req.setAttribute("c55", orthothrop.getC55());
        req.setAttribute("c66", orthothrop.getC66());
        req.setAttribute("c12", orthothrop.getC12());
        req.setAttribute("c13", orthothrop.getC13());
        req.setAttribute("c23", orthothrop.getC23());


        // Objekt, dass das Servlet zur Verfügung stellt
        // anschließend in lokale Variable schreiben
        // leitet Antwort und Antwortobjekt weiter

        RequestDispatcher dispatcher = req.getRequestDispatcher("/antwort.jsp");
        dispatcher.forward(req, resp);


    }
}

